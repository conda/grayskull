# List of python-windrose contributors and notable users (sorted alphabetically)

- Pete Bachant - Wind Farm Engineer at WindESCo - https://github.com/petebachant
- Brian Blaylock - University of Utah Department of Atmospheric Sciences - https://github.com/blaylockbk
- Ryan Brown - United States Environmental Protection Agency - https://www.epa.gov/
- daniclaar - Baum lab Applied ecology for impacted oceans - University of Victoria, BC, Canada - https://github.com/daniclaar
- Sébastien Celles - Université de Poitiers - IUT de Poitiers - https://github.com/scls19fr - project maintainer and co-author
- Filipe Fernandes - Research Software Engineer contractor for SECOORA/IOOS - https://github.com/ocefpaf
- Daniel Garver - United States Environmental Protection Agency - https://www.epa.gov/
- Fabien Maussion - Research Centre for Climate at the University of Innsbruck - https://github.com/fmaussion
- James McCann - Ramboll - https://github.com/mccannjb
- Ivan Ogasawara - https://github.com/xmnlab
- Julian Quick - National Renewable Energy Laboratory, Golden, CO - https://github.com/kilojoules
- Lionel Roubeyrie - LIMAIR - https://github.com/LionelR - original author
- Bruno Ruas De Pinho - https://github.com/brunorpinho
- Samuël Weber - Institut des Géosciences de l'Environnement, Grenoble, France, https://github.com/weber-s
- 15b3 - https://github.com/15b3

[Full Github contributors list](https://github.com/python-windrose/windrose/graphs/contributors).

and maybe more...
